import logo from './resources/images/logo.svg'
import './App.css';
import minion from './resources/images/min.jpg'
// import min2 from '../public/m2.jpeg'
const user = {
  name: 'jack',
  imageUrl: 'https://cdn.pixabay.com/photo/2016/04/27/18/33/minion-1357223__340.jpg',
  imageSize: 180,
};
function App() {
  var height='300px';
  return (
    <div className="App">
      {/* <img src={min2}/> */}
      <p>minion Name: </p>{user.name}
      <img src={user.imageUrl} width={user.imageSize} height={height}/>
      <img src="https://cdn.pixabay.com/photo/2016/04/27/18/33/minion-1357223__340.jpg"/>
        <img src={logo} className="App-logo" alt="logo" />
        <img src={minion} height={height}/>
    </div>
  );
}

export default App;
