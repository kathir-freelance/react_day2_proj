# Getting Started with Create React App

image shouldnot be kept in public folder

ensure that images is imported and stored in a variable name
import minion from './resources/images/min.jpg'

u can directly refer to the url without import in src attribute as below 
  <img src="https://cdn.pixabay.com/photo/2016/04/27/18/33/minion-1357223__340.jpg"/>

  u can also refer to url inside an object which may be coming from api call (fetch,ajax)

  const user = {
  name: 'jack',
  imageUrl: 'https://cdn.pixabay.com/photo/2016/04/27/18/33/minion-1357223__340.jpg',
  imageSize: 180,
};

 <img src={user.imageUrl} width={user.imageSize} />