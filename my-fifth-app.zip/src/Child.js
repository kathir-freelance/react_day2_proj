import SubChild from './SubChild';


export default function Child(props) {
  return (
    <div>
      Child:=   {props.valA}  {props.valB}
         <SubChild valB={props.valB}/>
    </div>
  )
}