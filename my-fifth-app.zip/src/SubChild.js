import GrandChild from "./GrandChild";



export default function SubChild(props) {
    return (
      <div>
        SubChild:=   {props.valA}  {props.valB}
        <GrandChild valA={props.valA} valB={props.valB}/>
      </div>
    )
  }