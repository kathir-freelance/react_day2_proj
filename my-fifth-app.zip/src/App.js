import logo from './logo.svg';
import './App.css';
import Child from './Child';
import React from 'react'
var a=333;
var b=900;

function App(props) {
  console.log(this)// undefined 
  //u cant access props , state
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
           <Child valA={a} valB={b}/>
         
         </p>
         <A/>
      </header>
    </div>
  );
}

export default App;
class A extends React.Component{
  constructor(){
    super()
    this.state={
      a:34
    }
    console.log(this)
    console.log(this.state)
  }
   handle=function(){

  }
  render(){
    return(
      <h1>hi</h1>
    )
  }
}