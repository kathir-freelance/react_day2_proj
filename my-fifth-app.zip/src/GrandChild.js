


export default function GrandChild(props) {
    return (
      <div>
        GrandChild:=   {props.valA}  {props.valB}
      </div>
    )
  }