import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';

const container=document.getElementById('root');
const root = ReactDOM.createRoot(container);
root.render(
  <>
    <App />{/* valA  is a props/property*/}
    {/* <App valA={a+90} valB="930"/>
    <App valA={a+9090} valB="930"/> */}
 </>
);

//in react 16
//ReactDOM.render(element, container)
// https://stackoverflow.com/questions/48389208/reactdom-render-vs-react-component-render-difference#:~:text=component's%20render%20method.-,ReactDOM.,that%20make%20up%20the%20component.