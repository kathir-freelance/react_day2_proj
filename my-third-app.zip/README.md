### old state code
export default class App extends React.Component{

  state={
    timeZone:{},
    name:'ddd'
  }

 constructor(){
  super();
  console.log('constructor called');
  const resp=fetch('https://jsonplaceholder.typicode.com/posts')
  .then((response) => 
      this.state.timeZone=response.json())
      resp.then(x=>x.map(y=>console.log(y)))
         }
  render(){
    
    console.log('render called')
    return(
      <div className="App">
        <h1>hi</h1>
      </div>
    )
  }
}


// import {Component} from 'react';
// class App extends Component{
  
// }

// import React,{Component} from 'react';
// class App extends React.Component{
  
// }
// export default App;