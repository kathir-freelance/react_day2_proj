import {Component} from 'react'
export default class Child extends Component{
constructor(){
    super()
    console.log('child constr called')
}
    render(){
        console.log('child render')
        return(
            <h1>name is {this.props.name}</h1>
        )
    }
}

// export default function Child(props){
//     console.log('child called')
//     return <h1>name is  {props.name}</h1>
// }