import logo from './logo.svg';
import './App.css';

// function App() {
//   return (
//     <div className="App">
    
//     </div>
//   );
// }

import React from 'react'
import Child from './Child';
export default class App extends React.Component{

 state={
  name:'aaa',
  age:34
 }
 
 constructor(){
  super()
  console.log('constr called')
  this.state={
    name:'bbc',
    age:35
  }
 }
 handleClick=()=>{
  console.log('clicked');
  console.log(this)
  this.setState({name:'fff'});
 }
//when ever index.js loads <app> comp- this render will be called
  render()//life cycle method - automatic is called
  {    
    console.log('render called')
    return(
      <div className="App">
       
       <Child name={this.state.name}/>  <h1>- age is {this.state.age}</h1>
        <button onClick={this.handleClick}>click</button>
      </div>
    )
  }
}
