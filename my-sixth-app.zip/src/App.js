import logo from './logo.svg';
import './App.css';
import Child from './Child';
import {useState} from 'react'

var username="aja";//this is not right way to manage state
//this doeant belong to APP component
function App() {
  let [username,setUserName]=useState("default");
  
  // setUserName=(n)=>{
  //   console.log('clicked ',n)
  //   username=n
  //   console.log(username)
  // }
  return (
    <div className="App">
      in app- {username}
      <input onChange={(event)=>setUserName(event.target.value)}></input>
      {/* <button onClick={()=>setUserName('ajay')}>click</button> */}
      <button onClick={(event)=>setUserName('ajay')}>click</button>
      <Child name={username}/>
    </div>
  );
}

export default App;
