export default function Child(props){
    return(
        <h1>in child {props.name}</h1>
    )
}