import Greet from "../Greetings";



function UserHome() {
  return (
    <div className="App">
        <Greet/> user page
    </div>
  );
}

export default UserHome;
