

import Greet from "../Greetings";
function AdminHome() {
  return (
    <div className="App">
       <Greet/>  admin page
    </div>
  );
}

export default AdminHome;
