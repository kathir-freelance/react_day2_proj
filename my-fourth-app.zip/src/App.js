
import './App.css';
import React,{Component} from 'react'
import UserHome from './user/userHome';
import AdminHome from './admin/adminHome';
import Home from './Home';
class App extends Component{
  
 constructor(){
  super()
  this.state=
  {
    isAdmin:true,
    boxType:'hidden',
    valForHome:"this is homepage"
  };
 }
  changeAdminLogin=()=>{
    this.setState({boxType:this.state.boxType==='text'?'hidden':'text'})
    this.setState({isAdmin:!this.state.isAdmin})
    console.log(this.state.isAdmin)
   
  }
  
 
  render(){
    return (
    <div className="App">
      <Home v={this.state.valForHome}/>
      <input type={this.state.boxType}/>
       hi {this.state.isAdmin.toString()}...
      {this.state.isAdmin?<UserHome/> :<AdminHome/>}
       <button onClick={this.changeAdminLogin}>click</button>
       {/* {()=>this.changeAdminLogin()} */}
    </div>
  );
  }
}

export default App;
