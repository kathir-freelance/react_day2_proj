//functional comp - arrow fns
const Greet=()=> <h1>welcome </h1>
//functional comp - arrow fns


export default Greet;
