let Home=(props)=> <h1>{props.v}</h1>
export default Home;